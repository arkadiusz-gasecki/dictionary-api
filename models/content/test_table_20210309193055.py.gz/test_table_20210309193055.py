### GENERATED AT: 2021-03-07 17:27:30

from db import db

class TestTableModel(db.Model):
	__tablename__ = 'test_table'

	id = db.Column(db.Integer, primary_key=True)
	col2 = db.Column(db.SmallInteger)
	col3 = db.Column(db.Integer)
	col4 = db.Column(db.Integer)
	col5 = db.Column(db.Numeric(18, 5, asdecimal=False))
	col6 = db.Column(db.Float)
	col7 = db.Column(db.Date)
	col8 = db.Column(db.DateTime)
	col9 = db.Column(db.String(50))
	col10 = db.Column(db.String(50))
	status = db.Column(db.String(100))

	def __init__(self, col2, col3, col4, col5, col6, col7, col8, col9, col10, status):
		self.col2 = col2
		self.col3 = col3
		self.col4 = col4
		self.col5 = col5
		self.col6 = col6
		self.col7 = col7
		self.col8 = col8
		self.col9 = col9
		self.col10 = col10
		self.status = status

	def update(self, col3, col4, col5, col6, col7, col8, col9, col10, status):
		self.col3 = col3
		self.col4 = col4
		self.col5 = col5
		self.col6 = col6
		self.col7 = col7
		self.col8 = col8
		self.col9 = col9
		self.col10 = col10
		self.status = status

	def json(self):
		return {
			'col2' : self.col2
			, 'col3' : self.col3
			, 'col4' : self.col4
			, 'col5' : self.col5
			, 'col6' : self.col6
			, 'col7' : str(self.col7)
			, 'col8' : str(self.col8)
			, 'col9' : self.col9
			, 'col10' : self.col10
			, 'status' : self.status
		}

	def json_with_id(self):
		return {
			self.id : self.json()
		}

	@classmethod
	def arguments(self):
		return {
			'logical_key': 'col2',
			'column_list': [
				{
					'name': 'col2',
					'type': ' int',
					'required': False
				},
				{
					'name': 'col3',
					'type': ' int',
					'required': True
				},
				{
					'name': 'col4',
					'type': ' int',
					'required': False
				},
				{
					'name': 'col5',
					'type': 'str',
					'required': False
				},
				{
					'name': 'col6',
					'type': ' float',
					'required': False
				},
				{
					'name': 'col7',
					'type': ' str',
					'required': False
				},
				{
					'name': 'col8',
					'type': ' str',
					'required': False
				},
				{
					'name': 'col9',
					'type': 'str',
					'required': False
				},
				{
					'name': 'col10',
					'type': 'str',
					'required': False
				},
				{
					'name': 'status',
					'type': 'str',
					'required': True
				},
			]
		}

	@classmethod
	def find_by_id(cls,_id):
		return cls.query.filter_by(id=_id).first()

	@classmethod
	def find_by_logical_key(cls,_id):
		return cls.query.filter_by(col2=_id).first()

	def save_to_db(self):
		db.session.add(self)
		db.session.commit()

	def delete_from_db(self):
		db.session.delete(self)
		db.session.commit()

